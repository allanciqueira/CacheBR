'use strict';
var app = angular.module('app', ['ngRoute', 'ui.bootstrap']);

app.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {
  
  $routeProvider.when('/home', {templateUrl: 'partials/home.html', controller: 'homeCtrl'});
  $routeProvider.when('/estatisticasServ', {templateUrl: 'partials/estatisticasServ.html', controller: 'estatisticasServCtrl'});

  $routeProvider.otherwise({redirectTo: '/home'});
}]);


app.run(function($rootScope, $location) {
	$rootScope.$on('$routeChangeStart', function() {
	});
});
