'use strict';

app.controller('estatisticasServCtrl', ['$scope', '$http', 'dashService', 
        function($scope, $http, dashService){
	
	$scope.sistemas = [];
	$scope.sistema = null;
	$scope.transacoes = [];
	$scope.transacao = null;
	$scope.servidores = [];
	
	$scope.loading = false;
	$scope.mensagem = false;
	$scope.mensagemDescricao = '';
	
	$scope.ativaAba = function(servidor){
		console.log(servidor);
		$.each($scope.servidores, function(i){
			$scope.servidores[i].active = '';
			if($scope.servidores[i].nome == servidor.nome){
				$scope.servidores[i].active = 'active';	
			}
		});
	}
	
	
	$scope.fechar = function(){
		$scope.mensagem = false;	
	}
	
	dashService.querySistemas(function(sistemas){
		if(sistemas != null && sistemas.length > 0){
			$scope.sistemas = sistemas;
		} else {
			$scope.mensagem = true;
			$scope.mensagemDescricao = 'Não foi possivel encontrar nenhum sistema!';
		}
	});
	
	$scope.recuperaTransacoes = function(){
		$scope.loading = true;
		$scope.mensagem = false;
		$scope.transacoes = [];
		$scope.transacao = null;
		dashService.queryTransacoesPorSistema(function(transacoes){
			$scope.loading = false;
			if(transacoes != null && transacoes.length>0){
				$scope.transacoes = transacoes;	
			} else {
				$scope.mensagem = true;
				$scope.mensagemDescricao = 'Não foi possivel encontrar nenhuma transação!';
			}
		}, $scope.sistema);
	};
	
	
	$scope.recuperaDados = function(){
		dashService.querySumarioServidores(function(dados){
			$scope.servidores = [];
			$.each(dados, function(i){
				var servidor = {};
				servidor.nome = dados[i].servidor;
				servidor.hits = dados[i].hits;
				servidor.misses = dados[i].misses;
				servidor.totaltrxs = dados[i].totaltrxs;
				servidor.porcentagem = dados[i].porcentagem;
				servidor.estatisticashits = dados[i].estatisticashits;
				servidor.estatisticasmisses = dados[i].estatisticasmisses;
				servidor.estatisticasexpiry = dados[i].estatisticasexpiry;
				servidor.objectscount = dados[i].objectscount;
				servidor.active = '';
				if(i == 0){
					servidor.active = 'active';
					$scope.servidor = servidor;
				}
				$scope.servidores.push(servidor);
			});
		}, $scope.sistema, $scope.transacao);
	}
	
	$scope.format = function(num){
	    var n = num.toString(), p = n.indexOf('.');
	    return n.replace(/\d(?=(?:\d{3})+(?:\.|$))/g, function($0, i){
	        return p<0 || i<p ? ($0+'.') : $0;
	    });
	}
}]);