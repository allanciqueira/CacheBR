'use strict';

app.controller('homeCtrl', ['$scope', '$http', 'dashService', 
        function($scope, $http, dashService){
	
	$scope.sistemas = [];
	$scope.sistema = null;
	$scope.transacoes = [];
	$scope.transacao = null;
	
	$scope.hits = 0;
	$scope.misses = 0;
	$scope.total = 0;
	$scope.objectsCount = 0;
	$scope.hits5Minutos = 0;
	$scope.misses5Minutos = 0;
	$scope.percent5Minutos = 0;

	$scope.loading = true;
	$scope.mensagem = false;
	$scope.mensagemDescricao = '';
	
	
	$scope.fechar = function(){
		$scope.mensagem = false;	
	}
	
	dashService.querySistemas(function(sistemas){
		$scope.loading = false;
		if(sistemas != null && sistemas.length > 0){
			$scope.sistemas = sistemas;
		} else {
			$scope.mensagem = true;
			$scope.mensagemDescricao = 'Não foi possivel encontrar nenhum sistema!';
		}
	});
	
	$scope.recuperaTransacoes = function(){
		$scope.loading = true;
		$scope.mensagem = false;
		$scope.transacoes = [];
		$scope.transacao = null;
		dashService.queryTransacoesPorSistema(function(transacoes){
			$scope.loading = false;
			if(transacoes != null && transacoes.length>0){
				$scope.transacoes = transacoes;	
			} else {
				$scope.mensagem = true;
				$scope.mensagemDescricao = 'Não foi possivel encontrar nenhuma transação!';
			}
		}, $scope.sistema);
	};
	
	$scope.recuperaEstatistica = function(){
		$scope.loading = true;
		$scope.hits = 0;
		$scope.misses = 0;
		$scope.total = 0;
		$scope.objectsCount = 0;
		$scope.loading = true;
		$scope.mensagem = false;
		$scope.totalSumario = 0
		
		$scope.hits5Minutos = 0;
		$scope.misses5Minutos = 0;
		$scope.percent5Minutos = "0";
		
		//recupera estatisticas
		dashService.queryEstatisticas(function(estatistica){
			
			if(estatistica != null && estatistica.length > 0 && estatistica[0].hits != null){
				
				$scope.hits = $scope.format(estatistica[0].hits);
				$scope.misses = $scope.format(estatistica[0].misses);
				$scope.total = $scope.format(estatistica[0].totaltrxs);
				
				dashService.querySumarioGeral(function(sumarioGeral){
					if(sumarioGeral!= null){
						$scope.hits5Minutos = $scope.format(sumarioGeral[0].hits);
						$scope.misses5Minutos = $scope.format(sumarioGeral[0].misses);
						
						var porcentagem = Number(sumarioGeral[0].porcentagem);
						
						$scope.percent5Minutos =  porcentagem.toFixed(2).replace(".", ",") + '%';
						
						$scope.objectsCount = $scope.format(sumarioGeral[0].objetosmemoria);
					}
					
					
					//recuper sumario
					dashService.querySumario(function(sumario){
						$scope.loading = false;
						
						var tamanho = sumario.length;
						var labels = [];
						var hitsData = [];
						var missesData = [];
						var percentData = [];
						var total = [];
						
						//recupera data
						$.each(sumario, function(i){
							labels.push(sumario[tamanho - i - 1].data);
							var hits = sumario[tamanho - i - 1].hits;
							var misses = sumario[tamanho - i - 1].misses;
							var valor = sumario[tamanho - i - 1].percent;
							var total = hits + misses ;
							
							//hitsData.push(valor);
							hitsData.push(hits);
							
							//missesData.push(100 - valor);
							missesData.push(misses);
							
							percentData.push(valor);
						});
						
						var lineChartData = {
								labels : labels,
								datasets : [
									{
										label: "Misses",
										fillColor: 'rgba(0,0,0,0)',
									    strokeColor: '#f9243f',
									    pointColor: '#f9243f',
										data : missesData
									},{
										label: "Hits",
										fillColor: 'rgba(0,0,0,0)',
									    strokeColor: '#8ad919',
									    pointColor: '#8ad919',
										data : hitsData
									}
								]
							}
						
						var ctx = document.getElementById("line-chart").getContext("2d");
						
						 new Chart(ctx).Line(lineChartData, {
								responsive: true
							});
						 $scope.loading = false;
					}, $scope.sistema, $scope.transacao);
				}, $scope.sistema, $scope.transacao);
			} else {
				$scope.mensagem = true;
				$scope.mensagemDescricao = 'Não foi possivel encontrar nenhum valor para a transação!';
			}
		}, $scope.sistema, $scope.transacao);
	};
	
	$scope.format = function(num){
		if(num != null){
			var n = num.toString(), p = n.indexOf('.');
		    return n.replace(/\d(?=(?:\d{3})+(?:\.|$))/g, function($0, i){
		        return p<0 || i<p ? ($0+'.') : $0;
		    });	
		} else{
			return 0;
		}
	    
	}
}]);