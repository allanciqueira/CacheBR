'use strict';

app.factory('dashService', ['$http', function($http,$window){
	var urlBase = 'rest/Controller/';
	
    var dataFactory = {};

    dataFactory.querySistemas = function (callback) {
        $http.get(urlBase + 'QuerySistemas/').
            then(function(response) {
                //recupera lista
                var lista = response.data;
                callback(lista);
            },
            function(response) {
                callback(null);
        });
    };
    
    dataFactory.queryServidores = function (callback) {
        $http.get(urlBase + 'QueryServidores/').
            then(function(response) {
                //recupera lista
                var lista = response.data;
                callback(lista);
            },
            function(response) {
                callback(null);
        });
    };
    
    dataFactory.queryTransacoesPorSistema = function (callback, ambiente) {
        $http.get(urlBase + 'QueryTransacoesbySistema/' + ambiente).
            then(function(response) {
                //recupera lista
                var lista = response.data;
                callback(lista);
            },
            function(response) {
                callback(null);
        });
    };
    
    dataFactory.querySumario = function (callback, ambiente, transacao) {
        $http.get(urlBase + 'SumarioGrafico/' + ambiente + '/' + transacao).
            then(function(response) {
                //recupera lista
                var lista = response.data;
                callback(lista);
            },
            function(response) {
                callback(null);
        });
    };
    
    dataFactory.queryEstatisticas = function (callback, ambiente, transacao) {
        $http.get(urlBase + 'Sumario/' + ambiente + '/' + transacao + '/24/HOUR').
            then(function(response) {
                //recupera lista
                var lista = response.data;
                callback(lista);
            },
            function(response) {
                callback(null);
        });
    };
    
    dataFactory.querySumarioGeral = function (callback, ambiente, transacao) {
        $http.get(urlBase + 'SumarioGeralTrxSistema/' + ambiente + '/' + transacao).
            then(function(response) {
                //recupera lista
                var lista = response.data;
                callback(lista);
            },
            function(response) {
                callback(null);
        });
    };
    
    dataFactory.querySumarioServidores = function (callback, ambiente, transacao) {
        $http.get(urlBase + 'SumarioServidores/' + ambiente + '/' + transacao).
            then(function(response) {
                //recupera lista
                var lista = response.data;
                callback(lista);
            },
            function(response) {
                callback(null);
        });
    };

    return dataFactory;
}])